abline(h=mean(galton$child),col="blue",lwd=2)
abline(v=mean(galton$parent),col="blue",lwd=2)