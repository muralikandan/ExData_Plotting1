# Histogram
hist(cars$mpgCity, xlab="Miles per Gallon (MPG)", main="")